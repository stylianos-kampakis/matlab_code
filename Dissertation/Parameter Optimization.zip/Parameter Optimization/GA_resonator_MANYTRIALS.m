%This file runs many times the genetic algorithm for parameter optimization
%for the resonator neurons and saves the results

fid = fopen('resonate.bin', 'a+');
%%
for kk=1:500
%This part runs the genetic algorithm
options = gaoptimset('PopulationSize',150,'Generations',20);

lb=[-10;-10;-85;-10];
ub=[10;10;-50;10];
[x,fval] = ga(@min_resonator,4,[],[],[],[],lb,ub,[],options);

%% 
%Save the results
fprintf(fid,'%f %f %f %f \r\n',[x]);
end
fclose(fid)