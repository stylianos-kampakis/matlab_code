%This file runs many times the genetic algorithm for parameter optimization
%for the rebound spiking neurons and saves the results

total_trials=30000;
fid = fopen('rebound_data.bin', 'a+');
for iterations=1:total_trials

%%
low_th=-randi(400,1,1);
up_th=randi(400,1,1);

object_func=@(x) min_rebound(x,low_th,up_th);
%This part runs the genetic algorithm
options = gaoptimset('Generations',10,'PopulationSize',[100],'FitnessLimit',0);

lb=[-10;-10;-90;-10];
ub=[10;10;-40;10];
[x,fval] = ga(object_func,4,[],[],[],[],lb,ub,[],options);


%%
firings_buffer=zeros(10,1);


%Save the results
if fval==0  
    fprintf(fid,'%f %f %f %f %i %i\r\n',[x low_th up_th]);
end

end
fclose(fid);

buffer=[];
fid = fopen('rebound_data.bin');



current=fgetl(fid);
while current~=-1
buffer=[buffer;str2num(current)];
current=fgetl(fid);
end

scatter(buffer(:,5),buffer(:,6),'.')