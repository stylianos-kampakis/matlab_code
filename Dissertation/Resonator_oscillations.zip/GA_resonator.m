
%%

%This part runs the genetic algorithm
options = gaoptimset('PlotFcns',@gaplotbestf,'PopulationSize',100);

lb=[-5;-5;-80;-20];
ub=[5;5;-50;20];
[x,fval] = ga(@min_resonator,4,[],[],[],[],lb,ub,[],options);

%% 
%This part of the script reads the solution, simulates the neuron and plots
%the membrane voltage.

close all
Ne=1;  
a=x(1);
b=x(2);
c=x(3);
d=x(4);
re=rand(Ne,1);      
total_firings=[];

%This part of the code is actually based on the simulation provided by
%Izhikevich
I=0;
v=-65;    % Initial values of v
u=b.*v; 
firings=[];             % spike timings
v_matrix=[];
for t=1:500            % simulation of 1000 ms
  % thalamic input  
  
   
  fired=find(v>=30);    % indices of spikes
  firings=[firings; t+0*fired,fired];
  v(fired)=c(fired);
  u(fired)=u(fired)+d(fired);

  v=v+0.5*(0.04*v.^2+5*v+140-u+I); % step 0.5 ms

  u=u+a.*(b.*v-u);                 % stability
  v_matrix=[v_matrix v];
  I=0;
  
  %Send an input at t=100
  if t==100
     I=100; 
  end  
  
end

if isempty(firings)
firings=Inf;  
end
total_firings=[total_firings;firings(1)];



%Here I plot the voltage

close all
plot(1:t,v_matrix);
firings

